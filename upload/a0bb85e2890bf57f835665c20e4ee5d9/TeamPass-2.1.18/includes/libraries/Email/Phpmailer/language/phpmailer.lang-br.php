<?php
/**
 * PHPMailer language file.
 * Portuguese Version
 * By Paulo Henrique Garcia - paulo@controllerweb.com.br
 */

$PHPMAILER_LANG = array();
$PHPMAILER_LANG["provide_address"] = 'Vocé deve fornecer pelo menos um endereéo de destinatério de email.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailer néo suportado.';
$PHPMAILER_LANG["execute"] = 'Néo foi possével executar: ';
$PHPMAILER_LANG["instantiate"] = 'Néo foi possével instanciar a funééo mail.';
$PHPMAILER_LANG["authenticate"] = 'Erro de SMTP: Néo foi possével autenticar.';
$PHPMAILER_LANG["from_failed"] = 'Os endereéos de rementente a seguir falharam: ';
$PHPMAILER_LANG["recipients_failed"] = 'Erro de SMTP: Os endereéos de destinatério a seguir falharam: ';
$PHPMAILER_LANG["data_not_accepted"] = 'Erro de SMTP: Dados néo aceitos.';
$PHPMAILER_LANG["connect_host"] = 'Erro de SMTP: Néo foi possével conectar com o servidor SMTP.';
$PHPMAILER_LANG["file_access"] = 'Néo foi possével acessar o arquivo: ';
$PHPMAILER_LANG["file_open"] = 'Erro de Arquivo: Néo foi possével abrir o arquivo: ';
$PHPMAILER_LANG["encoding"] = 'Codificaééo desconhecida: ';
