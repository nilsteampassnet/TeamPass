<?php
/**
 * PHPMailer language file.
 * Polish Version, encoding: windows-1250
 * translated from english lang file ver. 1.72
 */

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'Naleéy podaé prawidéowy adres email Odbiorcy.';
$PHPMAILER_LANG["mailer_not_supported"] = 'Wybrana metoda wysyéki wiadomoéci nie jest obséugiwana.';
$PHPMAILER_LANG["execute"] = 'Nie moéna uruchomié: ';
$PHPMAILER_LANG["instantiate"] = 'Nie moéna wywoéaé funkcji mail(). Sprawdé konfiguracjé serwera.';
$PHPMAILER_LANG["authenticate"] = 'Bééd SMTP: Nie moéna przeprowadzié autentykacji.';
$PHPMAILER_LANG["from_failed"] = 'Nastépujécy adres Nadawcy jest jest nieprawidéowy: ';
$PHPMAILER_LANG["recipients_failed"] = 'Bééd SMTP: Nastépujécy ' .
                                       'odbiorcy sé nieprawidéowi: ';
$PHPMAILER_LANG["data_not_accepted"] = 'Bééd SMTP: Dane nie zostaéy przyjéte.';
$PHPMAILER_LANG["connect_host"] = 'Bééd SMTP: Nie moéna poééczyé sié z wybranym hostem.';
$PHPMAILER_LANG["file_access"] = 'Brak dostépu do pliku: ';
$PHPMAILER_LANG["file_open"] = 'Nie moéna otworzyé pliku: ';
$PHPMAILER_LANG["encoding"] = 'Nieznany sposéb kodowania znakéw: ';
