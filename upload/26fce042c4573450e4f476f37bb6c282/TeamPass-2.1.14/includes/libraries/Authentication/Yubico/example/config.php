<?php
$CFG[__CLIENT_ID__] = 1851;
$CFG[__CLIENT_KEY__] = 'oBVbNt7IZehZGR99rvq8d6RZ1DM=';
# You need to modify the following string if you want to test two-factor modes.
$CFG[__PGDB__] = "host=pghost.example.org dbname=dbname user=username password=password connect_timeout=2";
