<?php
/**
 * PHPMailer language file.
 * Japanese Version
 * By Mitsuhiro Yoshida - http://mitstek.com/
 * This file is written in EUC-JP.
 */

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'éééʤééȤé1éĥ᡼é륢éɥ쥹éé' .
                                     'éééꤹééɬéפéééééޤééé';
$PHPMAILER_LANG["mailer_not_supported"] = ' é᡼é顼éééééݡééȤéééƤééޤééé';
$PHPMAILER_LANG["execute"] = 'é¹ԤǤééޤéééǤééé: ';
$PHPMAILER_LANG["instantiate"] = 'é᡼ééؿééééééééưééޤéééǤééééé';
$PHPMAILER_LANG["authenticate"] = 'SMTPééé顼: ǧéڤǤééޤéééǤééééé';
$PHPMAILER_LANG["from_failed"] = 'ééééFroméééɥ쥹é˴ְ㤤ééééééޤé: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTPééé顼: éééμééééԥééɥ쥹éé ' .
                                       'éְ㤤ééééééޤé: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTPééé顼: éǡééééééééééդééééޤéééǤééééé';
$PHPMAILER_LANG["connect_host"] = 'SMTPééé顼: SMTPéۥééȤééé³éǤééޤéééǤééééé';
$PHPMAILER_LANG["file_access"] = 'éեééééé˥ééééééééǤééޤééé: ';
$PHPMAILER_LANG["file_open"] = 'éեéééé륨é顼: éեééééé򳫤ééޤééé: ';
$PHPMAILER_LANG["encoding"] = 'éééééʥéé󥳡ééǥééé: ';
